import axios from "axios";

const API = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api",
});

// ✅ Signup
export async function signup(userData: any) {
  const res = await API.post("/signup", userData);
  return res.data;
}

// ✅ Login
export async function login(emailId: string, password: string) {
  const res = await API.post("/login", { emailId, password });
  return res.data;
}

// ✅ Change Password
export async function changePassword(
  emailId: string,
  oldPassword: string,
  newPassword: string
) {
  const res = await API.post("/change-password", {
    emailId,
    oldPassword,
    newPassword,
  });
  return res.data;
}

// ✅ Verify Account
export async function verify(emailId: string) {
  const res = await API.post("/verify", { emailId });
  return res.data;
}
